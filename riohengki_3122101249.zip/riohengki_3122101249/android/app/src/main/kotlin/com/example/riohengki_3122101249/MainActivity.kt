package com.example.riohengki_3122101249

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
